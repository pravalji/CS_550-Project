# Utils

Here are the tools we used for the project : 
* json library `nlohmann`