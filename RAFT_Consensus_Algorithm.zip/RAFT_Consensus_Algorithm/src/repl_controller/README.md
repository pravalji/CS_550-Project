# The Controller

* The controller is one of the 3 main parts of the project
* The controller is the process that allows you to interact with all the clients and servers by using REPL commands in a Command Line Interafce (CLI)
* You can find a list of all the REPL commands in the `README.md` file at the root of the repository.